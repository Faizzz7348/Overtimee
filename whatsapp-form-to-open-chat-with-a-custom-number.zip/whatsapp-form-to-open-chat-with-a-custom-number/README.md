# WhatsApp form to open chat with a custom number

A Pen created on CodePen.

Original URL: [https://codepen.io/lcmartinez/pen/LLpEOe](https://codepen.io/lcmartinez/pen/LLpEOe).

