var vm = new Vue({
  el: '#app',
  data: {
    tel: '',
  },
  methods: {
    sendMessage: function (event) {
      window.open('https://api.whatsapp.com/send?phone=57' + this.tel.trim());
    }
  }
});