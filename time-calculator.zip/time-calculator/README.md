# Time Calculator

A Pen created on CodePen.

Original URL: [https://codepen.io/trimalcione/pen/gabzBd](https://codepen.io/trimalcione/pen/gabzBd).

Divide, sum or subtract time in hh:mm:ss format