function toHHMMSS(sec_num) {
  sec_num = parseInt(sec_num, 10);
  var t = [];
  t[0] = Math.floor(sec_num / 3600);
  t[1] = Math.floor((sec_num - (t[0] * 3600)) / 60);
  t[2] = sec_num - (t[0] * 3600) - (t[1] * 60);
  
  for(var i=0; i<t.length;i++) {
    t[i] = addZero(t[i]);
  }
  
  var time = t[0] +':'+ t[1] +':'+ t[2];
  return time;
}

function addZero(x) {
  (x<10)?(x = "0" + x):(x);
  return x;
}

$("#select-operation").change(function () {
  var op = $(this).val();
  if (op == 'add' || op == 'sub'){
    $("#n").hide();
    $("#timeOp").show();
  }
  else if (op == 'div') {
    $("#timeOp").hide();
    $("#n").show();
  }
});

function main () {
  var time = [$("#hh").val(), $("#mm").val(), $("#ss").val()],
      timeOp = [$("#hhOp").val(), $("#mmOp").val(), $("#ssOp").val()],
      op = $("#select-operation").val(),
      n = $("#n").val(),
      timeToSec = 0,
      timeToSecOp = 0,
      result = 0;
  
  (!n)?(n = 1):(n);
  
  for(var i=0; i<time.length;i++) {
    time[i] = addZero(time[i]);
    timeOp[i] = addZero(timeOp[i]);
    time[i] = parseInt(time[i]);
    timeOp[i] = parseInt(timeOp[i]);
  }
  
  timeToSec = (time[0]*60*60 + time[1]*60 + time[2]);
  timeToSecOp = (timeOp[0]*60*60 + timeOp[1]*60 + timeOp[2]);
  
  for(var i=0; i<time.length;i++) {
    time[i] = addZero(time[i]);
    timeOp[i] = addZero(timeOp[i]);
  }
  
  if(op == 'div') {
    result = timeToSec/n;
    $("#result").html("<h2>" + time[0] + ":" + time[1] + ":" + time[2] + " = " + toHHMMSS(result) + "</h2> <h5>x" + n + "</h5>");
  }
  else if(op == 'add') {
    result = timeToSec + timeToSecOp;
    $("#result").html("<h2>" + time[0] + ":" + time[1] + ":" + time[2] + " + " + timeOp[0] + ":" + timeOp[1] + ":" + timeOp[2] + " = " + toHHMMSS(result));
  }
  else if(op == 'sub') {
    if(timeToSec < timeToSecOp) {
      $("#result").html("<h2>This operation gives a negative result.</h2>");
      return false;
    } else {
      result = timeToSec - timeToSecOp;
      $("#result").html("<h2>" + time[0] + ":" + time[1] + ":" + time[2] + " - " + timeOp[0] + ":" + timeOp[1] + ":" + timeOp[2] + " = " + toHHMMSS(result));
    }
  }
  
}

$("#submit").click(main);
$("body").keypress(function(event) {
  if ( event.which == 13 ) {
     event.preventDefault();
     main();
  }
});

$("#clear").click(function () {
  $("#hh").val('');
  $("#mm").val('');
  $("#ss").val('');
  $("#hhOp").val(''); 
  $("#mmOp").val(''); 
  $("#ssOp").val('');
  $("#n").val('');
  $("#result").html("");
});