const workerForm = document.getElementById('workerForm'); //Get form

//Add listener to the btn
workerForm.addEventListener('submit', function(event) {
  event.preventDefault();  // Prevent default form submission
  
  // Retrieve the form values
  let name = document.getElementById('name').value;
  let startTime = document.getElementById('startTime').value;
  let endTime = document.getElementById('endTime').value; // Fixed to match HTML
  let actualEndTime = document.getElementById('actualEndTime').value;
  
  let overtime = calculateOvertime(startTime, endTime, actualEndTime);
  
  alert("Overtime added");
  // Call the addOvertime function
  addOvertime(name, startTime, endTime, overtime);
  
  workerForm.reset();
});

// Function to add overtime info to the page
function addOvertime(name, startTime, endTime, overtime) {
  let workerInfoHTML = `
    <div class="workerContainer">
      <ul>
        <li>Name: ${name}</li>
        <li>Start Time: ${startTime}</li>
        <li>End Time: ${endTime}</li>
        <li>Overtime: ${overtime}</li>
      </ul>
    </div>
  `;
  
  //Where the new html goes
  const container = document.querySelector('.overtimeCards');
  container.innerHTML += workerInfoHTML;
}

//Super bs function to calculate overtime
function calculateOvertime(startTime, endTime, actualEndTime) {
  
  function timeToSeconds(time) {
    const [hours, minutes] = time.split(':').map(Number);
    return (hours * 3600) + (minutes * 60); 
  }

  const scheduledEndTimeInSeconds = timeToSeconds(endTime);
  const actualEndTimeInSeconds = timeToSeconds(actualEndTime);
  let overtimeInSeconds = actualEndTimeInSeconds - scheduledEndTimeInSeconds;

  overtimeInSeconds = overtimeInSeconds < 0 ? 0 : overtimeInSeconds;

  let overtimeHours = Math.floor(overtimeInSeconds / 3600);
  let overtimeMinutes = Math.floor((overtimeInSeconds % 3600) / 60);

  // Ensure both hours and minutes are always displayed with two digits
  overtimeHours = String(overtimeHours).padStart(2, '0');
  overtimeMinutes = String(overtimeMinutes).padStart(2, '0');

  return `${overtimeHours}:${overtimeMinutes}`;
}

